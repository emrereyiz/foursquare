<template>
<div>
  <app-header></app-header>
  <div class="container">
    <div class="col-12">
      <transition name="fade">
        <router-view></router-view>
      </transition>
    </div>
  </div>
  <app-footer></app-footer>
</div>
</template>

<script>
import Header from "./components/main/header";
import Footer from "./components/main/footer";

export default {
  components: {
    appHeader: Header,
    appFooter: Footer,
  },
}
</script>

<style>
body,html{
  margin:0;
  padding:0;
  height: 100%;
  min-height: 100%;
  background: #6441A5;  /* fallback for old browsers */
  background: -webkit-linear-gradient(to bottom, #2a0845, #6441A5);  /* Chrome 10-25, Safari 5.1-6 */
  background: linear-gradient(to bottom, #2a0845, #6441A5); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
  color:#fff;
}
  header{
    text-align: center;
    padding:20px 0;
    background: #606c88;  /* fallback for old browsers */
    background: -webkit-linear-gradient(to bottom, #3f4c6b, #606c88);  /* Chrome 10-25, Safari 5.1-6 */
    background: linear-gradient(to bottom, #3f4c6b, #606c88); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
  }
  header a{
    color:#fff;
    padding:0 20px;
  }
  footer{
    bottom: 0;
    width: 100%;
    height: auto;
    color:#fff;
    padding:20px 0;
    background: #606c88;  /* fallback for old browsers */
    background: -webkit-linear-gradient(to bottom, #3f4c6b, #606c88);  /* Chrome 10-25, Safari 5.1-6 */
    background: linear-gradient(to bottom, #3f4c6b, #606c88); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
  }
  section{
    display: inline-block;
    width: 100%;
    padding:20px 0; 
    background: #442270;
    border: solid 1px #fff;
    box-shadow: 0 0 20px 0 #000;
    border-radius: 20px;
    margin:40px 0;
  }
  .jumbotron{
    background-color: transparent;
  }
  .display-2{
    padding:0;
    position:relative;
    top:-30px;
  }
  .fade-enter-active, .fade-leave-active {
    transition: opacity .5s;
  }
  .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
    opacity: 0;
  }
</style>
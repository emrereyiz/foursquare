<template>
    <div>
        <app-search></app-search>
    </div>
</template>
<script>
import Search from "../detail/Search";

export default {
    components: {
        appSearch: Search
    },
}
</script>

<template>
    <section>
        <div class="jumbotron">
            <h1 class="display-2">İletişim</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="javascript:;">Movue</a></li>
                    <li class="breadcrumb-item active" aria-current="page">İletişim</li>
                </ol>
            </nav>
            <p class="lead">İletişim formu için aşağıdaki bilgileri doldurmalısınız.</p>
            <form>
                <div class="form-group">
                    <label for="exampleInputEmail1">Email Adres</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" v-model="email">
                    <small id="emailHelp" class="form-text text-muted">Söz veriyorum emailini kimseyle paylaşmıcam.</small>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Güvenlik için unutmayacağın bir şey yaz.</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" v-model="key1">
                </div>
                <strong>{{controlKeys}}</strong>
                <div class="form-group">
                    <label for="exampleInputPassword2">Tekrar 3 kelimeyi yaz.</label>
                    <input type="password" class="form-control" id="exampleInputPassword2" v-model="key2">
                </div>
                <div class="form-group form-check">
                    <input v-model="check" type="checkbox" class="form-check-input" id="exampleCheck1">
                    <label class="form-check-label" for="exampleCheck1">Güvenlik Onayı.</label>
                </div>
                <button class="btn btn-primary" v-on:click.prevent="checkForm">Onay</button>
                </form>
                <ul class="list-group">
                    <li class="list-group-item">{{validateResult}}</li>
                </ul>
        </div>
    </section>
</template>
<script>
export default {
    data(){
        return{
            email: null,
            key1: null,
            key2: null,
            check: null,
            validate: false,
        }
    },
    computed: {
        validateResult(){
            if(!this.validate){
                return "Henüz form gönderilmedi."
            }else{
                return "Her şey okey."
            }
        },
        controlKeys(){
            return this.key1 != this.key2 ? "Güvenlik kelimeleri aynı olmak zorunda." : "";
        },
    },
    methods: {
        checkForm(){
            if(this.email != null && (this.key1 == this.key2 && this.key1.length > 0) && this.check ){
                this.validate = true;
            }else{
                this.validate = false;
            }
        },
    },
}
</script>
<style scoped>
    .list-group{
        padding:30px 0;
    }
    .list-group,
    .list-group-item{
        background-color: transparent;
    }
    strong{
        text-shadow:1px 1px 1px #000;
    }
</style>
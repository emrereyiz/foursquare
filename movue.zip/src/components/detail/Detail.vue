<template>
<div class="col-12">
    <div class="row">
        <div class="col-3">
            <app-right>
                <h1>{{getMovie.Title}}</h1>
                <img v-bind:src="getMovie.Poster" alt="">
            </app-right>
        </div>    
        <div class="col-9">
            <app-left>
                <p>{{getMovie.Plot}}</p>
                <strong>Tür <span>{{getMovie.Genre}}</span></strong>
                <strong>Puan <span>{{getMovie.imdbRating}}</span></strong>
                <strong>Yönetmen <span>{{getMovie.Director}}</span></strong>
                <strong>Yayın Tarihi <span>{{getMovie.Released}}</span></strong>
                <strong>Ülke <span>{{getMovie.Country}}</span></strong>
            </app-left>
        </div>   
    </div> 
</div>
</template>

<script>

import Left from "./detailLeft";
import Right from "./detailRight";

export default{
    components:{
        appLeft: Left,
        appRight: Right,
    },
    data(){
        return{
            detailData: null,
        }
    },
    computed:{
        getMovie(){
            return this.$store.state.detailMovie
        }
    },

}
</script>

<style scoped>
    .card{color:#000;}
    img{width:100%;height:auto;}
    strong{
        width:100%;
        display:inline-block;
    }
    strong span{
        font-weight: normal;
    }
</style>
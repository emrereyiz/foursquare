<template>
<div class="">
    <slot></slot>
</div>
</template>

<script>
export default{
}
</script>

<style scoped>
</style>
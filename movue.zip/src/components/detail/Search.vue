<template>
<div>
    <div class="form-group">
        <input class="col-9" type="text" v-model="searchKey">

        <button class="col-2" v-on:click="getMovieDetail">Ara
            
        </button>

    </div>
    <transition name="fade">
        <app-list v-if="movieControl == 'list'">
        </app-list>
    </transition>
    
    <transition name="fade">
        <app-detail v-if="movieControl == 'detail'">
        </app-detail>
    </transition>
</div>
</template>
<script>
import List from "./List";
import Detail from "./Detail";
    export default {
        components: {
            appList: List,
            appDetail: Detail,
        },
        data(){
            return{
                searchKey: null,
                requestStatus: false,
                movieList: null,
            }
        },
        computed: {
            movieControl(){
                return this.requestStatus = this.$store.state.movieStatus;
            },
        },
        methods: {
            getMovieDetail(){
                this.requestStatus = this.$store.state.movieStatus;
                if(this.$store.state.searchKey != this.searchKey){
                    this.$store.dispatch("movieRequest", this.searchKey);
                };
            },
        },
    }
</script>
<style>
.form-group{
    margin:40px 0;
}
input,button{
    margin:0;
    padding:0;
}
</style>
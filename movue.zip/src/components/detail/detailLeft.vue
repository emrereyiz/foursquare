<template>
<div class="col-12">
    <slot></slot>
</div>
</template>

<script>
export default{
}
</script>

<style scoped>
</style>
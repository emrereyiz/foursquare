<template>
<div class="col-lg-12">
        <app-card>
    <div class="row">
            <div v-for="movie in returnMovie" class="card col-lg-3">
                <div class="card-body">
                    <img v-bind:src="movie.Poster" class="card-img-top" alt="">
                    <h5 class="card-title">{{ movie.Title }}</h5>
                    <p class="card-text">{{ movie.Plot }}</p>
                    <span class="card__info"><strong>Çıkış Tarihi</strong>: {{movie.Year}}</span>
                    <a v-on:click="getTitle(movie.Title)" href="javascript:;" class="btn btn-primary">Detay</a>
                </div>
            </div>
    </div>
        </app-card>
</div>
</template>

<script>
import Card from "./listCard";
    export default{
        components:{
            appCard: Card,
        },
        computed:{
            returnMovie(){
                return this.$store.state.listData
            },
        },
        methods:{
            getTitle(title){
                if(title != this.$store.state.detailTitle){
                    this.$store.dispatch("detailRequest", title);
                };
                this.$store.state.detailTitle = title;
            },
        },
    }
</script>

<style scoped>
    .card{color:#000;}
    img{width:100%;height:auto;}
</style>
<template>
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-6 text-left">
          Emre Reyiz &copy;
        </div>
        <div class="col-6 text-right">
          Emre Reyiz2 &copy;
        </div>
      </div>
    </div>
  </footer> 
</template>
<script>
export default {
}
</script>
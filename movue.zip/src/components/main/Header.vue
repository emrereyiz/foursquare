

<template>
  <header class="col-12">
    <nav>
      <router-link to="/" tag="a">
      Ana Sayfa
      </router-link>
      <router-link to="/about" tag="a">
      Hakkımızda
      </router-link>
      <router-link to="/contact" tag="a">
      İletişim
      </router-link>
    </nav>
  </header>
</template>
<script>
export default {
}
</script>
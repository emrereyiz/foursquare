import Vue from 'vue'
import App from './App.vue';
import {configResource}  from "./config/resource";
import {configVuex, store}  from "./config/state";

import VueRouter from "vue-router";
import {routes} from './config/routes';



const router = new VueRouter({
  routes : routes,
  mode: 'history',
});


new Vue({
  el: '#app',
  store: store,
  router: router,
  render: h => h(App)
});
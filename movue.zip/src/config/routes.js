import Vue from 'vue';
import VueRouter from "vue-router";



import Home from "../components/page/Home";
import About from "../components/page/About";
import Contact from "../components/page/Contact";

export const routes = [
        {
            path: '/',
            component: Home,
            name: 'anasayfa',
        },
        {
            path: '/about',
            component: About,
            name: 'hakkimizda',
        },
        {
            path: '/contact',
            component: Contact,
            name: 'iletisim',
        },
        {// 404
            path: '*',
            component: Home,
            name: '404',
        }
];

Vue.use(VueRouter);

import Vue from 'vue';
import VueResource from "vue-resource";

Vue.use(VueResource);
Vue.http.options.root = "http://www.omdbapi.com/?apikey=77b6e08a&?apikey=77b6e08a";
import Vue from 'vue';
import Vuex from "vuex";

Vue.use(Vuex);

export const store = new Vuex.Store({
    // state sayesinde istek sonuclarimi elimde tutuyorum.
    state: {

        movieStatus: false,
        searchKey:  null,
        listData: null,
        detailTitle: null,
        detailMovie: null,
    },
    // mutations araciligi ile request'lerimi parse ediyorum.
    mutations:{
        getMovie(state, value){
            state.searchKey = value;
            this._vm.$http.get('plot=full&s='+state.searchKey).then(response => {
                let data = response.body.Search;
                state.listData=data;
                state.movieStatus = 'list';
            });
        },
        getDetail(state, value){
            state.detailTitle = value;
            this._vm.$http.get('plot=full&t='+state.detailTitle).then(response => {
                let data = response.body;
                state.detailMovie = data;
                state.movieStatus = 'detail';
            });
        },
    },
    // mutations'i tetikliyorum.
    actions: {
        movieRequest({commit}, params){
            commit("getMovie", params)
        },
        detailRequest({commit}, params){
            commit("getDetail", params)
        },
    },
});